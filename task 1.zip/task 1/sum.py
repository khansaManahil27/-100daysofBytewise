# Get the first number from the user
first_number = float(input("Enter first number: "))

# Get the second number from the user
second_number = float(input("Enter second number: "))

# Calculate the sum
sum_of_numbers = first_number + second_number

# Print the sum
print(f"The sum is: {sum_of_numbers}")