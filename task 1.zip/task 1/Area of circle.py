import math

# Get the radius from the user
radius = float(input("Enter the radius of the circle: "))

# Calculate the area using the formula πr^2
area = math.pi * (radius ** 2)

# Print the area
print(f"The area of the circle is: {area}")